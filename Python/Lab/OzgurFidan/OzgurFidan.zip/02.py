"""
- İki tamsayı alan bir Python işlevi yazın.
- Bu işlev, ikinci tamsayının ilk tamsayılarını bulur ve döndürür.
    - Diyelim ki ilk parametre 8 ve ikinci parametre 3,
        - Fonksiyonlar hesaplar ve 83 döndürür.
"""

buNedir = lambda sayi1, sayi2 : print(str(sayi1) + str(sayi2))

buNedir(8, 3)
# Ödev anlaşılmadı, fakat verilen örnek çalışıyo :)